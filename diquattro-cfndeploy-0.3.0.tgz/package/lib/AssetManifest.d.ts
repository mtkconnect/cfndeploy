export declare const AssetManifestMetadataKey = "DeployAssetManifest";
export interface AssetDescriptor {
    name: string;
    key: string;
    bucketParam: string;
    keyParam: string;
}
export interface AssetManifest {
    assets: AssetDescriptor[];
}
export declare const decodeAssetDescriptor: import("@fmtk/decoders").ObjectDecoder<AssetDescriptor>;
export declare const decodeAssetManifest: import("@fmtk/decoders").ObjectDecoder<AssetManifest>;
//# sourceMappingURL=AssetManifest.d.ts.map