import { AssetManifest, AssetManifestMetadataKey } from './AssetManifest.js';
export declare const DeployStackVersionMetadataKey = "DeployStackVersion";
export interface BaseTemplate {
    Metadata: {
        [AssetManifestMetadataKey]?: AssetManifest;
        [DeployStackVersionMetadataKey]: string;
    };
}
export declare const decodeBaseTemplate: import("@fmtk/decoders").ObjectDecoder<BaseTemplate>;
//# sourceMappingURL=BaseTemplate.d.ts.map