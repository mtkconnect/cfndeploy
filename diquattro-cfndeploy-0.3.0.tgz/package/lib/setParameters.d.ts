import { Parameter } from '@aws-sdk/client-cloudformation';
export type SetParameterValue = Parameter | string | undefined;
export type SetParameterValues<K extends string = string> = {
    [P in K]?: SetParameterValue;
};
export type ParameterValueProvider = () => SetParameterValue | PromiseLike<SetParameterValue>;
export type ParameterValueProviders<K extends string = string> = {
    [P in K]?: SetParameterValue | ParameterValueProvider;
};
export declare function setParameters(parameters: Record<string, Parameter>, values: SetParameterValues, defaults?: boolean): void;
export declare function setProvideParameters(parameters: Record<string, Parameter>, values: ParameterValueProviders, defaults?: boolean): Promise<void>;
//# sourceMappingURL=setParameters.d.ts.map