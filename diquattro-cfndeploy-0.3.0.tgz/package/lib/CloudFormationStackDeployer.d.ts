import { CloudFormationClient, CloudFormationClientConfig, DescribeChangeSetOutput, StackEvent } from '@aws-sdk/client-cloudformation';
import { S3Client, S3ClientConfig } from '@aws-sdk/client-s3';
import { TypedEmitter } from 'tiny-typed-emitter';
import { AwsCommonServiceConfig } from './CommonServiceConfig.js';
import { DownloadTemplateProgressStats } from './DownloadTemplateProgressStats.js';
import { ParameterValue } from './ParameterValue.js';
import { ParameterValueProviders, SetParameterValues } from './setParameters.js';
import { TemplateLocation } from './TemplateLocation.js';
export interface CreateChangeSetOptions<P extends string = string> {
    name?: string;
    parameterDefaults?: SetParameterValues<P>;
    parameters?: SetParameterValues<P>;
    provideParameterDefaults?: ParameterValueProviders<P>;
    provideParameters?: (current: Record<P, ParameterValue>) => SetParameterValues<P> | PromiseLike<SetParameterValues<P>>;
}
export declare enum ChangeSetCreateStatus {
    ChangeSetCreateComplete = "ChangeSetCreateComplete",
    ChangeSetCreateInProgress = "ChangeSetCreateInProgress",
    ChangeSetCreating = "ChangeSetCreating",
    DescribeStack = "DescribeStack",
    PrepareParameters = "PrepareParameters"
}
export declare enum ChangeSetExecuteStatus {
    ChangeSetCreateComplete = "ChangeSetCreateComplete",
    ChangeSetCreateInProgress = "ChangeSetCreateInProgress",
    ChangeSetCreating = "ChangeSetCreating",
    DescribeStack = "DescribeStack",
    PrepareParameters = "PrepareParameters"
}
export declare enum CloudFormationStackEventKey {
    ChangeSetCreateStatus = "ChangesetCreateStatus",
    DownloadTemplateProgress = "DownloadTemplateProgress",
    ExecuteEvent = "ExecuteEvent"
}
export interface CloudFormationStackEvents {
    [CloudFormationStackEventKey.ChangeSetCreateStatus](status: ChangeSetCreateStatus, changeset?: DescribeChangeSetOutput): void;
    [CloudFormationStackEventKey.DownloadTemplateProgress](stats: DownloadTemplateProgressStats): void;
    [CloudFormationStackEventKey.ExecuteEvent](event: StackEvent): void;
}
export declare class CloudFormationStackDeployer extends TypedEmitter<CloudFormationStackEvents> {
    private readonly cfn;
    private readonly s3;
    private readonly stackName;
    private readonly templateLocation;
    private _changeset;
    private _template;
    get changeset(): DescribeChangeSetOutput | undefined;
    private set changeset(value);
    constructor(dep: {
        awsConfig?: AwsCommonServiceConfig;
        cfn?: CloudFormationClient;
        cfnConfig?: CloudFormationClientConfig;
        s3?: S3Client;
        s3Config?: S3ClientConfig;
        stackName: string;
        template?: TemplateLocation;
    });
    /**
     * Create a changeset for the stack.
     */
    createChangeSet(opts?: CreateChangeSetOptions): Promise<DescribeChangeSetOutput>;
    /**
     * Execute the changeset.
     */
    executeChangeSet(): Promise<boolean>;
    /**
     * Stream events for the changeset.
     */
    streamEvents(stackId: string, token?: string): Promise<boolean>;
    /**
     * Get the existing stack info, if any.
     */
    private getStack;
    /**
     * Download and validate the template data.
     */
    private getTemplate;
}
//# sourceMappingURL=CloudFormationStackDeployer.d.ts.map