type UndefinedProperties<T> = {
    [P in keyof T]-?: undefined extends T[P] ? P : never;
}[keyof T];
type OptionalUndefined<T> = Partial<Pick<T, UndefinedProperties<T>>> & Pick<T, Exclude<keyof T, UndefinedProperties<T>>>;
export declare function stripUndefined<T>(value: T): OptionalUndefined<T>;
export {};
//# sourceMappingURL=stripUndefined.d.ts.map