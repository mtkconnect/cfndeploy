export declare function assertCondition(condition: unknown, message?: string): asserts condition;
//# sourceMappingURL=assertCondition.d.ts.map