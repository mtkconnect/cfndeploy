import { CloudFormationClient, StackEvent } from '@aws-sdk/client-cloudformation';
export declare function streamChangeSetEvents(client: CloudFormationClient, stackId: string, token?: string): AsyncIterableIterator<StackEvent>;
//# sourceMappingURL=streamChangeSetEvents.d.ts.map