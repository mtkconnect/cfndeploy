import { S3Client, S3ClientConfig } from '@aws-sdk/client-s3';
import { DeploymentBundle, ProgressStats } from '@awboost/cfnassets';
import { TypedEmitter } from 'tiny-typed-emitter';
export interface DeploymentUploaderEvents {
    assetUploadProgress(name: string, stats: ProgressStats): void;
}
export declare class DeploymentUploader extends TypedEmitter<DeploymentUploaderEvents> {
    upload(bundle: DeploymentBundle, { bucket, maxConcurrency, s3Config, s3, }: {
        bucket: string;
        maxConcurrency?: number;
        s3?: S3Client;
        s3Config?: S3ClientConfig;
    }): Promise<void>;
}
//# sourceMappingURL=DeploymentUploader.d.ts.map