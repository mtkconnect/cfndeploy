export interface TemplateLocation {
    S3Bucket: string;
    S3Key: string;
}
//# sourceMappingURL=TemplateLocation.d.ts.map