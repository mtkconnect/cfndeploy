import { DeploymentBundle } from '@awboost/cfnassets';
import { TemplateBuilder } from '@awboost/cfntemplate';
export interface BundleSpec {
    builder: TemplateBuilder;
    bundle: DeploymentBundle;
    name: string;
    version: string;
}
export declare function buildTemplate({ builder, bundle, name, version, }: BundleSpec): Promise<number>;
//# sourceMappingURL=buildTemplate.d.ts.map